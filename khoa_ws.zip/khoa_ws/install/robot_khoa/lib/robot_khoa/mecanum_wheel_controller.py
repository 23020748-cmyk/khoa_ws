#!/usr/bin/env python3

from math import copysign

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray


class MecanumWheelController(Node):
    def __init__(self) -> None:
        super().__init__("mecanum_wheel_controller")

        self.declare_parameter("wheel_radius", 0.03)
        self.declare_parameter("wheel_separation_x", 0.162)
        self.declare_parameter("wheel_separation_y", 0.120)
        self.declare_parameter("cmd_timeout", 0.5)
        self.declare_parameter("max_wheel_speed", 18.0)

        self.wheel_radius = float(self.get_parameter("wheel_radius").value)
        self.lx = float(self.get_parameter("wheel_separation_x").value) / 2.0
        self.ly = float(self.get_parameter("wheel_separation_y").value) / 2.0
        self.cmd_timeout = float(self.get_parameter("cmd_timeout").value)
        self.max_wheel_speed = float(self.get_parameter("max_wheel_speed").value)

        self.last_cmd = self.get_clock().now()
        self.last_twist = Twist()

        self.command_pub = self.create_publisher(
            Float64MultiArray, "/wheel_controller/commands", 10
        )
        self.create_subscription(Twist, "/cmd_vel", self.cmd_vel_callback, 10)
        self.create_timer(0.05, self.publish_wheel_speeds)

        self.get_logger().info(
            "Listening on /cmd_vel and publishing wheel commands to /wheel_controller/commands"
        )

    def cmd_vel_callback(self, msg: Twist) -> None:
        self.last_twist = msg
        self.last_cmd = self.get_clock().now()

    def publish_wheel_speeds(self) -> None:
        if (self.get_clock().now() - self.last_cmd).nanoseconds * 1e-9 > self.cmd_timeout:
            twist = Twist()
        else:
            twist = self.last_twist

        k = self.lx + self.ly
        vx = twist.linear.x
        vy = twist.linear.y
        wz = twist.angular.z

        front_right = (vx - vy - k * wz) / self.wheel_radius
        rear_right = (vx + vy - k * wz) / self.wheel_radius
        rear_left = (vx - vy + k * wz) / self.wheel_radius
        front_left = (vx + vy + k * wz) / self.wheel_radius

        wheel_speeds = [
            -front_right,
            -rear_right,
            rear_left,
            front_left,
        ]

        clamped = [
            copysign(min(abs(speed), self.max_wheel_speed), speed)
            for speed in wheel_speeds
        ]
        self.command_pub.publish(Float64MultiArray(data=clamped))


def main() -> None:
    rclpy.init()
    node = MecanumWheelController()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
