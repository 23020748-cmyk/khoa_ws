import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("robot_khoa")
    robot_path = os.path.join(pkg_share, "urdf", "robot_khoa.urdf")
    rviz_config = os.path.join(pkg_share, "rviz", "robot_khoa.rviz")

    with open(robot_path, "r", encoding="utf-8") as robot_file:
        robot_description = robot_file.read().replace("$(find robot_khoa)", pkg_share)
    if robot_description.startswith("<?xml"):
        robot_description = "\n".join(robot_description.splitlines()[1:])

    return LaunchDescription(
        [
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                output="screen",
                parameters=[{"robot_description": robot_description}],
            ),
            Node(
                package="joint_state_publisher_gui",
                executable="joint_state_publisher_gui",
                output="screen",
            ),
            Node(
                package="rviz2",
                executable="rviz2",
                output="screen",
                arguments=["-d", rviz_config],
            ),
        ]
    )
