#!/usr/bin/env python3

from typing import Dict, List

import rclpy
from builtin_interfaces.msg import Duration, Time
from gazebo_msgs.srv import ApplyJointEffort
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import JointState
from std_msgs.msg import String


class ArmCommander(Node):
    def __init__(self) -> None:
        super().__init__("arm_commander")

        self.joint_names: List[str] = [
            "banh1_joint",
            "banh2_joint",
            "banh3_joint",
            "banh4_joint",
            "link2_joint",
            "ef_joint",
        ]
        self.positions: Dict[str, float] = {
            "banh1_joint": 0.0,
            "banh2_joint": 0.0,
            "banh3_joint": 0.0,
            "banh4_joint": 0.0,
            "link2_joint": 0.0,
            "ef_joint": 0.0,
        }
        self.step = 0.12
        self.limits = {
            "link2_joint": (-1.2, 1.2),
            "ef_joint": (-1.0, 1.0),
        }
        self.efforts = {
            "link2_joint": 0.8,
            "ef_joint": 0.5,
        }

        # robot_state_publisher in Humble subscribes to /joint_states with BEST_EFFORT by default.
        # Publishing RELIABLE here can make them incompatible -> missing wheel/arm TF in RViz.
        joint_state_qos = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.joint_state_pub = self.create_publisher(JointState, "/joint_states", joint_state_qos)
        self.create_subscription(String, "/arm_cmd", self.arm_cmd_callback, 10)
        self.apply_effort_client = self.create_client(ApplyJointEffort, "/apply_joint_effort")
        self.create_timer(1.0, self.print_usage_once)
        self.create_timer(0.1, self.publish_joint_states)
        self._usage_printed = False

    def print_usage_once(self) -> None:
        if self._usage_printed:
            return
        self._usage_printed = True
        self.get_logger().info(
            "Use /arm_cmd with: joint1+, joint1-, joint2+, joint2-, home"
        )

    def arm_cmd_callback(self, msg: String) -> None:
        command = msg.data.strip().lower()
        if command == "joint1+":
            self.update_joint("link2_joint", self.step)
            self.apply_joint_effort("link2_joint", self.efforts["link2_joint"])
        elif command == "joint1-":
            self.update_joint("link2_joint", -self.step)
            self.apply_joint_effort("link2_joint", -self.efforts["link2_joint"])
        elif command == "joint2+":
            self.update_joint("ef_joint", self.step)
            self.apply_joint_effort("ef_joint", self.efforts["ef_joint"])
        elif command == "joint2-":
            self.update_joint("ef_joint", -self.step)
            self.apply_joint_effort("ef_joint", -self.efforts["ef_joint"])
        elif command == "home":
            self.positions["link2_joint"] = 0.0
            self.positions["ef_joint"] = 0.0
        else:
            self.get_logger().warning(f"Unsupported /arm_cmd command: {msg.data}")
            return

        self.publish_joint_states()

    def update_joint(self, joint_name: str, delta: float) -> None:
        lower, upper = self.limits[joint_name]
        next_position = self.positions[joint_name] + delta
        self.positions[joint_name] = min(max(next_position, lower), upper)

    def apply_joint_effort(self, joint_name: str, effort: float) -> None:
        if not self.apply_effort_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().warning("/apply_joint_effort is not available yet")
            return

        request = ApplyJointEffort.Request()
        request.joint_name = joint_name
        request.effort = effort
        request.start_time = Time(sec=0, nanosec=0)
        request.duration = Duration(sec=0, nanosec=300000000)
        self.apply_effort_client.call_async(request)

    def publish_joint_states(self) -> None:
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = list(self.joint_names)
        msg.position = [self.positions[name] for name in self.joint_names]
        self.joint_state_pub.publish(msg)


def main() -> None:
    rclpy.init()
    node = ArmCommander()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    main()
