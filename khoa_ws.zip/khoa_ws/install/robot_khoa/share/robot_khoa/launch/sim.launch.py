import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    package_name = "robot_khoa"
    pkg_share = get_package_share_directory(package_name)
    # Gazebo's `model://<model_name>/...` URI looks for `<model_name>` under entries in GAZEBO_MODEL_PATH.
    # Our meshes are installed to: <prefix>/share/robot_khoa/meshes/...
    # So we must add `<prefix>/share` (parent of pkg_share) to GAZEBO_MODEL_PATH.
    gazebo_share_root = os.path.dirname(pkg_share)
    robot_path = os.path.join(pkg_share, "urdf", "robot_khoa.urdf")
    rviz_config = os.path.join(pkg_share, "rviz", "robot_khoa.rviz")

    with open(robot_path, "r", encoding="utf-8") as robot_file:
        robot_description = robot_file.read().replace("$(find robot_khoa)", pkg_share)
    if robot_description.startswith("<?xml"):
        robot_description = "\n".join(robot_description.splitlines()[1:])

    use_rviz = LaunchConfiguration("rviz")
    use_sim_time = LaunchConfiguration("use_sim_time")
    gui = LaunchConfiguration("gui")

    rsp = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[
            {
                "robot_description": robot_description,
                "use_sim_time": use_sim_time,
            }
        ],
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory("gazebo_ros"), "launch", "gazebo.launch.py")
        ),
        launch_arguments={"gui": gui}.items(),
    )

    spawn_robot = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=[
            "-topic",
            "robot_description",
            "-entity",
            "robot_khoa",
            "-x",
            "0.0",
            "-y",
            "0.0",
            "-z",
            "0.05",
        ],
        output="screen",
    )

    arm_commander = Node(
        package=package_name,
        executable="arm_commander.py",
        output="screen",
        parameters=[{"use_sim_time": use_sim_time}],
    )

    rviz = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", rviz_config],
        parameters=[{"use_sim_time": use_sim_time}],
        condition=IfCondition(use_rviz),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("rviz", default_value="true"),
            DeclareLaunchArgument("use_sim_time", default_value="true"),
            DeclareLaunchArgument("gui", default_value="true"),
            SetEnvironmentVariable(
                name="GAZEBO_MODEL_PATH",
                value=os.pathsep.join(
                    filter(
                        None,
                        [
                            os.environ.get("GAZEBO_MODEL_PATH", ""),
                            gazebo_share_root,
                        ],
                    )
                ),
            ),
            SetEnvironmentVariable(
                name="GAZEBO_PLUGIN_PATH",
                value=os.pathsep.join(
                    filter(
                        None,
                        [
                            os.environ.get("GAZEBO_PLUGIN_PATH", ""),
                            "/opt/ros/humble/lib",
                        ],
                    )
                ),
            ),
            rsp,
            gazebo,
            spawn_robot,
            arm_commander,
            rviz,
        ]
    )
