# Bao cao giua ky robot_khoa

## 1. Tong quan he thong

`robot_khoa` la robot di dong 4 banh mecanum, co tay may 2 khop va cum cam bien co ban gom camera RGB, lidar 2D va GPS. Package duoc to chuc de khi clone ve co the build va chay bang mot lenh launch chinh, phuc vu muc tieu cham bai tren Gazebo va RViz.

## 2. Dang robot, dong hoc va kich thuoc

- Dang robot: mobile robot 4 banh mecanum.
- Co cau thao tac: tay may 2 khop quay.
- Kich thuoc than xe xap xi theo mesh:
  - dai: `0.19 m`
  - rong: `0.12 m`
  - cao tong the: `0.13 m`
- Duong kinh banh: `0.06 m`
- Ban kinh banh: `0.03 m`
- Khoang cach giua hai cum banh theo truc doc: `0.162 m`
- Khoang cach giua hai cum banh theo truc ngang: `0.120 m`

Robot nhan `geometry_msgs/msg/Twist` tren topic `/cmd_vel`. Trong Gazebo, chuyen dong duoc mo phong theo co che holonomic thong qua plugin planar move, phu hop voi nen tang mecanum cho giai doan giua ky. Dong hoc quy doi duoc mo ta bo sung trong `scripts/mecanum_wheel_controller.py` de mo rong sang muc quay toc do banh neu can.

## 3. Thiet ke SolidWorks va he truc toa do

Mo hinh co khi ban dau duoc thiet ke trong SolidWorks va xuat sang URDF/STL. Do he truc cua CAD khong trung truc chuan ROS, package da them cac frame trung gian:

- `base_footprint`: moc dat tai mat san, dung lam frame tham chieu gan nen.
- `base_link`: frame than xe chuan ROS, dung cho `cmd_vel`, `odom` va RViz.
- `chassis_link`: mesh co khi goc xuat tu SolidWorks.

He truc cua robot duoc quy uoc theo ROS:

- `x`: huong truoc robot
- `y`: huong ben trai
- `z`: huong len tren

## 4. Mo ta file URDF, lien ket link va cam bien

File `urdf/robot_khoa.urdf` gom cac nhom thanh phan:

### 4.1. Cum than xe

- `base_footprint`
- `base_link`
- `chassis_link`

`base_footprint` lien ket co dinh voi `base_link`, sau do `base_link` lien ket co dinh voi `chassis_link`.

### 4.2. Cum di chuyen

- `banh1_link`
- `banh2_link`
- `banh3_link`
- `banh4_link`

Bon banh duoc noi vao than bang cac khop:

- `banh1_joint`
- `banh2_joint`
- `banh3_joint`
- `banh4_joint`

### 4.3. Cum tay may

- `link2_link`
- `ef_link`

Hai khop tay may:

- `link2_joint`
- `ef_joint`

### 4.4. Cum cam bien

- `cam_link`
- `camera_optical_frame`
- `lidar_link`
- `gps_link`

Cam bien duoc cau hinh bang the `gazebo` trong chinh file URDF:

- Lidar 2D dung plugin `libgazebo_ros_ray_sensor.so`, xuat topic `/scan`
- Camera RGB dung plugin `libgazebo_ros_camera.so`, xuat topic `/camera/image_raw` va `/camera/camera_info`
- GPS dung plugin `libgazebo_ros_gps_sensor.so`, xuat topic `/gps/data`

## 5. Mo ta Gazebo va co che dieu khien

### 5.1. Launch chinh

File `launch/sim.launch.py` thuc hien cac buoc:

1. doc file URDF va nap `robot_description`
2. chay `robot_state_publisher`
3. mo Gazebo Classic
4. spawn robot vao mo phong
5. chay node `arm_commander.py`
6. mo RViz voi cau hinh san topic scan va image

### 5.2. Dieu khien de di dong

Robot nhan `Twist` qua topic `/cmd_vel`. Trong mo phong, plugin `libgazebo_ros_planar_move.so` dam nhiem:

- nhan lenh toc do
- cap nhat vi tri robot tren mat phang
- phat topic `/odom`
- phat TF `odom -> base_link`

De dieu khien bang ban phim:

```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args --remap cmd_vel:=/cmd_vel
```

### 5.3. Dieu khien tay may

Node `scripts/arm_commander.py` nhan lenh tu topic `/arm_cmd` dang `std_msgs/msg/String`:

- `joint1+`
- `joint1-`
- `joint2+`
- `joint2-`
- `home`

Node nay:

- goi service `/apply_joint_effort` cua Gazebo de tao chuyen dong cho hai khop tay may
- phat lien tuc `/joint_states` de RViz cap nhat cac khop dong

## 6. Cac thanh phan chinh cua code va structure folder

- `launch/`: cac launch file ROS 2
- `urdf/`: mo ta robot va plugin Gazebo
- `meshes/`: file STL tu SolidWorks
- `scripts/`: node python dieu khien
- `rviz/`: cau hinh RViz
- `config/`: file cau hinh du phong cho controller
- `docs/`: bao cao va tai lieu nop bai

## 7. Danh gia doi voi yeu cau nop bai

Package hien dap ung cac diem chinh sau:

- Co package robot doc lap de dua len GitHub
- Co URDF, meshes, launch, rviz, scripts, docs
- Co huong dan trong `README.md` de nguoi cham clone ve va chay
- Co liet ke package can cai them
- Launch chinh bat Gazebo, RViz, spawn robot
- Robot nhan `Twist` va di chuyen trong Gazebo
- Co node dieu khien tay may
- Co topic cam bien va cau hinh RViz san

## 8. Ket luan

`robot_khoa` da du dieu kien de dong goi thanh mot package nop bai giua ky. Nguoi cham chi can clone repo, build package, source workspace va chay:

```bash
ros2 launch robot_khoa sim.launch.py
```

Sau khi launch, robot xuat hien tren Gazebo va RViz, co the nhan `Twist` tu ban phim, dieu khien tay may bang topic `/arm_cmd`, va cac topic cam bien co san de kiem tra.
