import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():

    # 1. Khai báo thông tin package
    package_name = 'robot_khoa' 
    pkg_path = get_package_share_directory(package_name)

    # 2. Xử lý file URDF
    urdf_file = os.path.join(pkg_path, 'urdf', 'robot_khoa.urdf')
    with open(urdf_file, 'r') as infp:
        robot_description_config = infp.read()
    
    # Node robot_state_publisher
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description_config, 'use_sim_time': True}]
    )

    # 3. Mở Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')]),
    )

    # 4. Thả robot vào Gazebo (Spawn)
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', 
                   '-entity', 'robot_khoa_new',
                   '-z', '0.1'], # Thả cao hơn mặt đất 10cm để tránh kẹt
        output='screen'
    )

    return LaunchDescription([
        node_robot_state_publisher,
        gazebo,
        spawn_entity
    ])
